import { s } from './style';

export default function DesktopFrame() {
  return (
    <div style={s(`display:flex;flex-direction:column;align-items:flex-start`)}>
        <span className="frame-lbl">Desktop · 1440</span>
        <div data-screen-label="Desktop" style={s(`width:1440px;background:#efeaea;box-shadow:0 24px 70px rgba(0,0,0,.18);overflow:hidden;color:#141414`)}>
    
          
          <div style={s(`position:relative;height:572px`)}>
            <div style={s(`position:absolute;top:0;right:0;width:648px;height:570px;background:radial-gradient(60% 60% at 52% 48%,#4982fe 0%,#1e08b2 42%,#1300a8 100%)`)}></div>
            <div style={s(`position:absolute;left:145px;top:52px`)}>
              <div style={s(`display:flex;align-items:center;gap:9px`)}>
                <svg width="30" height="21" viewBox="0 0 44 30"><path fill="#E4002B" d="M22 1h20l-8 11H14z M2 18h20l8 11H10z"/></svg>
                <span style={s(`font-weight:800;font-size:20px;letter-spacing:.03em;color:#141a8f`)}>SUZUKI</span>
              </div>
              <h1 style={s(`font-weight:800;font-size:46px;line-height:1.12;margin:78px 0 0;color:#141414`)}>Suzuki Mobil Semarang</h1>
              <div style={s(`font-weight:600;font-size:33px;line-height:1.25;margin-top:6px;color:#141414`)}>Mobil Nyaman, Harga<br />Aman.</div>
              <div style={s(`width:360px;margin-top:26px`)}>
                <div style={s(`font-weight:700;font-size:13px;margin-bottom:6px`)}>Nama Penyewa</div>
                <div style={s(`background:#c0d8ff;border-radius:22px;height:36px;display:flex;align-items:center;padding:0 16px;font-weight:500;font-size:13px;color:#7f89b0`)}>Jenny Wilson</div>
                <div style={s(`display:flex;gap:22px;margin-top:14px`)}>
                  <div style={s(`flex:1`)}>
                    <div style={s(`font-weight:700;font-size:13px;margin-bottom:6px`)}>Pilih Tanggal Sewa</div>
                    <div style={s(`background:#c0d8ff;border-radius:22px;height:36px;display:flex;align-items:center;padding:0 16px;font-weight:500;font-size:13px;color:#7f89b0`)}>6/10/2025</div>
                  </div>
                  <div style={s(`flex:1`)}>
                    <div style={s(`font-weight:700;font-size:13px;margin-bottom:6px`)}>Pilih Tanggal Kembali</div>
                    <div style={s(`background:#c0d8ff;border-radius:22px;height:36px;display:flex;align-items:center;padding:0 16px;font-weight:500;font-size:13px;color:#7f89b0`)}>7/10/2025</div>
                  </div>
                </div>
                <div style={s(`font-weight:700;font-size:13px;margin:14px 0 6px`)}>Pilih Tipe Mobil</div>
                <div style={s(`background:#c0d8ff;border-radius:22px;height:36px;display:flex;align-items:center;padding:0 16px;font-weight:500;font-size:13px;color:#7f89b0`)}>Toyota Innova Reborn</div>
                <div style={s(`font-weight:700;font-size:13px;margin:14px 0 6px`)}>Pilih Kebutuhan</div>
                <div style={s(`background:#c0d8ff;border-radius:22px;height:36px;display:flex;align-items:center;padding:0 16px;font-weight:500;font-size:13px;color:#7f89b0`)}>Tanpa Supir</div>
                <div className="pesan-btn" style={s(`background:#4149DC;border-radius:24px;height:44px;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:19px;color:#fff;margin-top:16px`)}>Pesan Sekarang</div>
              </div>
            </div>
          </div>
    
          
          <div style={s(`padding:70px 0 0;text-align:center`)}>
            <h2 style={s(`font-weight:800;font-size:38px;margin:0 0 56px;color:#141414`)}>How To Order</h2>
            <div style={s(`display:flex;align-items:flex-start;justify-content:center;gap:0`)}>
              <div style={s(`width:290px`)}>
                <div style={s(`width:112px;height:112px;border-radius:22px;background:#c0d8ff;display:flex;align-items:center;justify-content:center;margin:0 auto`)}>
                  <svg width="50" height="50" viewBox="0 0 24 24" fill="#2b52a8"><path d="M12 2C7.9 2 4.5 5.3 4.5 9.4c0 5.4 6.3 11.7 7 12.4.3.3.7.3 1 0 .7-.7 7-7 7-12.4C19.5 5.3 16.1 2 12 2z"/><circle cx="12" cy="9.4" r="2.7" fill="#c0d8ff"/></svg>
                </div>
                <div style={s(`font-weight:700;font-size:15px;margin-top:22px;color:#141414`)}>Pilih Unit</div>
                <p style={s(`margin:8px auto 0;font-size:13px;line-height:1.45;color:#3f3f3f;max-width:210px`)}>Lorem ipsum dolor sit amet consectetur. Quis ac purus pulvinar.</p>
              </div>
              <div style={s(`width:120px;display:flex;align-items:center;justify-content:center;padding-top:44px`)}>
                <svg width="70" height="24" viewBox="0 0 70 24" fill="none" stroke="#111" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M4 12h58M54 5l9 7-9 7"/></svg>
              </div>
              <div style={s(`width:290px`)}>
                <div style={s(`width:112px;height:112px;border-radius:22px;background:#305BA4;display:flex;align-items:center;justify-content:center;margin:0 auto`)}>
                  <svg width="52" height="52" viewBox="0 0 24 24"><rect x="3.5" y="5" width="17" height="15" rx="2.4" fill="#fff"/><rect x="3.5" y="5" width="17" height="4.4" fill="#d7e0f2"/><line x1="8" y1="3" x2="8" y2="6.5" stroke="#fff" strokeWidth="2" strokeLinecap="round"/><line x1="16" y1="3" x2="16" y2="6.5" stroke="#fff" strokeWidth="2" strokeLinecap="round"/><text x="12" y="17.5" fontSize="8.5" fontWeight="700" textAnchor="middle" fill="#305BA4" fontFamily="Poppins">19</text></svg>
                </div>
                <div style={s(`font-weight:700;font-size:15px;margin-top:22px;color:#141414`)}>SPK</div>
                <p style={s(`margin:8px auto 0;font-size:13px;line-height:1.45;color:#3f3f3f;max-width:210px`)}>Lorem ipsum dolor sit amet consectetur. Quis ac purus pulvinar.</p>
              </div>
              <div style={s(`width:120px;display:flex;align-items:center;justify-content:center;padding-top:44px`)}>
                <svg width="70" height="24" viewBox="0 0 70 24" fill="none" stroke="#111" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M4 12h58M54 5l9 7-9 7"/></svg>
              </div>
              <div style={s(`width:290px`)}>
                <div style={s(`width:112px;height:112px;border-radius:22px;background:#c0d8ff;display:flex;align-items:center;justify-content:center;margin:0 auto`)}>
                  <svg width="54" height="54" viewBox="0 0 24 24" fill="#2b52a8"><path d="M5 11l1.5-3.8A2.2 2.2 0 0 1 8.6 5.8h6.8a2.2 2.2 0 0 1 2.1 1.4L19 11h.4A1.6 1.6 0 0 1 21 12.6V16a1 1 0 0 1-1 1h-1v1.1a1.1 1.1 0 0 1-2.2 0V17H7.2v1.1a1.1 1.1 0 0 1-2.2 0V17H4a1 1 0 0 1-1-1v-3.4A1.6 1.6 0 0 1 4.6 11z"/><circle cx="7.6" cy="14" r="1.2" fill="#c0d8ff"/><circle cx="16.4" cy="14" r="1.2" fill="#c0d8ff"/></svg>
                </div>
                <div style={s(`font-weight:700;font-size:15px;margin-top:22px;color:#141414`)}>Serah Terima</div>
                <p style={s(`margin:8px auto 0;font-size:13px;line-height:1.45;color:#3f3f3f;max-width:210px`)}>Lorem ipsum dolor sit amet consectetur. Quis ac purus pulvinar.</p>
              </div>
            </div>
          </div>
    
          
          <div style={s(`padding:96px 0 0;text-align:center`)}>
            <h2 style={s(`font-weight:800;font-size:38px;margin:0 0 14px;color:#141414`)}>Our Unit Cars</h2>
            <p style={s(`margin:0 auto 44px;font-size:13.5px;line-height:1.5;color:#3f3f3f;max-width:430px`)}>Lorem ipsum dolor sit amet consectetur. Nunc pulvinar arcu proin phasellus bibendum mauris proin nulla donec. Lorem non nunc odio lectus. Duis blandit.</p>
            <div style={s(`display:grid;grid-template-columns:repeat(3,370px);gap:20px;width:1150px;margin:0 auto 24px`)}>
              
              <div data-card style={s(`background:#fff;border-radius:16px;box-shadow:0 22px 40px rgba(20,20,60,.10);padding:26px 26px 24px;text-align:left`)}>
                <div style={s(`font-weight:800;font-size:24px;color:#141414`)}>XL7</div>
                <div style={s(`font-size:20px;color:#141414;margin-top:-3px`)}>Zeta</div>
                <img src="/assets/d_hiace.png" style={s(`width:100%;height:auto;display:block;margin:18px 0 20px`)} />
                <div style={s(`display:flex;justify-content:space-between;margin-bottom:16px;font-size:13.5px;color:#1a1a1a`)}>
                  <span style={s(`display:flex;align-items:center;gap:6px`)}><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="#1a1a1a" strokeWidth="1.7"><circle cx="12" cy="12" r="9.2"/><circle cx="12" cy="12" r="2.4" fill="#1a1a1a" stroke="none"/><path d="M4.2 10.5c2.2.4 4.4.6 7.8.6s5.6-.2 7.8-.6M12 14.4V21"/></svg>Manual</span>
                  <span style={s(`display:flex;align-items:center;gap:6px`)}><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="#1a1a1a" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><rect x="4" y="3.5" width="8.5" height="17" rx="1.6"/><line x1="4" y1="9" x2="12.5" y2="9"/><path d="M12.5 6.6l3.8 3v8a1.9 1.9 0 0 0 3.8 0V9.6"/></svg>Diesel</span>
                  <span style={s(`display:flex;align-items:center;gap:6px`)}><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="#1a1a1a" strokeWidth="1.7"><circle cx="12" cy="8" r="3.6"/><path d="M5 20c0-3.9 3.1-6 7-6s7 2.1 7 6"/></svg>Driver</span>
                </div>
                <div className="pesan-btn" style={s(`background:#4149DC;border-radius:22px;height:44px;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:18px;color:#fff`)}>Rp. 1.500.000</div>
              </div>
              <div data-card style={s(`background:#fff;border-radius:16px;box-shadow:0 22px 40px rgba(20,20,60,.10);padding:26px 26px 24px;text-align:left`)}>
                <div style={s(`font-weight:800;font-size:24px;color:#141414`)}>XL7</div>
                <div style={s(`font-size:20px;color:#141414;margin-top:-3px`)}>Beta</div>
                <img src="/assets/d_innova.png" style={s(`width:100%;height:auto;display:block;margin:18px 0 20px`)} />
                <div style={s(`display:flex;justify-content:space-between;margin-bottom:16px;font-size:13.5px;color:#1a1a1a`)}>
                  <span style={s(`display:flex;align-items:center;gap:6px`)}><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="#1a1a1a" strokeWidth="1.7"><circle cx="12" cy="12" r="9.2"/><circle cx="12" cy="12" r="2.4" fill="#1a1a1a" stroke="none"/><path d="M4.2 10.5c2.2.4 4.4.6 7.8.6s5.6-.2 7.8-.6M12 14.4V21"/></svg>Matic</span>
                  <span style={s(`display:flex;align-items:center;gap:6px`)}><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="#1a1a1a" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><rect x="4" y="3.5" width="8.5" height="17" rx="1.6"/><line x1="4" y1="9" x2="12.5" y2="9"/><path d="M12.5 6.6l3.8 3v8a1.9 1.9 0 0 0 3.8 0V9.6"/></svg>Diesel</span>
                  <span style={s(`display:flex;align-items:center;gap:6px`)}><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="#1a1a1a" strokeWidth="1.7"><circle cx="12" cy="8" r="3.6"/><path d="M5 20c0-3.9 3.1-6 7-6s7 2.1 7 6"/></svg>Optional</span>
                </div>
                <div className="pesan-btn" style={s(`background:#4149DC;border-radius:22px;height:44px;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:18px;color:#fff`)}>Rp. 450.000</div>
              </div>
              <div data-card style={s(`background:#fff;border-radius:16px;box-shadow:0 22px 40px rgba(20,20,60,.10);padding:26px 26px 24px;text-align:left`)}>
                <div style={s(`font-weight:800;font-size:24px;color:#141414`)}>XL7</div>
                <div style={s(`font-size:20px;color:#141414;margin-top:-3px`)}>Alpha</div>
                <img src="/assets/d_avanza.png" style={s(`width:100%;height:auto;display:block;margin:18px 0 20px`)} />
                <div style={s(`display:flex;justify-content:space-between;margin-bottom:16px;font-size:13.5px;color:#1a1a1a`)}>
                  <span style={s(`display:flex;align-items:center;gap:6px`)}><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="#1a1a1a" strokeWidth="1.7"><circle cx="12" cy="12" r="9.2"/><circle cx="12" cy="12" r="2.4" fill="#1a1a1a" stroke="none"/><path d="M4.2 10.5c2.2.4 4.4.6 7.8.6s5.6-.2 7.8-.6M12 14.4V21"/></svg>Matic</span>
                  <span style={s(`display:flex;align-items:center;gap:6px`)}><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="#1a1a1a" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><rect x="4" y="3.5" width="8.5" height="17" rx="1.6"/><line x1="4" y1="9" x2="12.5" y2="9"/><path d="M12.5 6.6l3.8 3v8a1.9 1.9 0 0 0 3.8 0V9.6"/></svg>Bensin</span>
                  <span style={s(`display:flex;align-items:center;gap:6px`)}><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="#1a1a1a" strokeWidth="1.7"><circle cx="12" cy="8" r="3.6"/><path d="M5 20c0-3.9 3.1-6 7-6s7 2.1 7 6"/></svg>Optional</span>
                </div>
                <div className="pesan-btn" style={s(`background:#4149DC;border-radius:22px;height:44px;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:18px;color:#fff`)}>Rp. 350.000</div>
              </div>
              
              <div data-card style={s(`background:#fff;border-radius:16px;box-shadow:0 22px 40px rgba(20,20,60,.10);padding:26px 26px 24px;text-align:left`)}>
                <div style={s(`font-weight:800;font-size:24px;color:#141414`)}>XL7</div>
                <div style={s(`font-size:20px;color:#141414;margin-top:-3px`)}>Alpha Kuro</div>
                <img src="/assets/d_brio.png" style={s(`width:100%;height:auto;display:block;margin:18px 0 20px`)} />
                <div style={s(`display:flex;justify-content:space-between;margin-bottom:16px;font-size:13.5px;color:#1a1a1a`)}>
                  <span style={s(`display:flex;align-items:center;gap:6px`)}><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="#1a1a1a" strokeWidth="1.7"><circle cx="12" cy="12" r="9.2"/><circle cx="12" cy="12" r="2.4" fill="#1a1a1a" stroke="none"/><path d="M4.2 10.5c2.2.4 4.4.6 7.8.6s5.6-.2 7.8-.6M12 14.4V21"/></svg>Matic</span>
                  <span style={s(`display:flex;align-items:center;gap:6px`)}><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="#1a1a1a" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><rect x="4" y="3.5" width="8.5" height="17" rx="1.6"/><line x1="4" y1="9" x2="12.5" y2="9"/><path d="M12.5 6.6l3.8 3v8a1.9 1.9 0 0 0 3.8 0V9.6"/></svg>Bensin</span>
                  <span style={s(`display:flex;align-items:center;gap:6px`)}><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="#1a1a1a" strokeWidth="1.7"><circle cx="12" cy="8" r="3.6"/><path d="M5 20c0-3.9 3.1-6 7-6s7 2.1 7 6"/></svg>Optional</span>
                </div>
                <div className="pesan-btn" style={s(`background:#4149DC;border-radius:22px;height:44px;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:18px;color:#fff`)}>Rp. 300.000</div>
              </div>
              <div data-card style={s(`background:#fff;border-radius:16px;box-shadow:0 22px 40px rgba(20,20,60,.10);padding:26px 26px 24px;text-align:left`)}>
                <div style={s(`font-weight:800;font-size:24px;color:#141414`)}>Fronx</div>
                <div style={s(`font-size:20px;color:#141414;margin-top:-3px`)}>GL</div>
                <img src="/assets/d_agya.png" style={s(`width:100%;height:auto;display:block;margin:18px 0 20px`)} />
                <div style={s(`display:flex;justify-content:space-between;margin-bottom:16px;font-size:13.5px;color:#1a1a1a`)}>
                  <span style={s(`display:flex;align-items:center;gap:6px`)}><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="#1a1a1a" strokeWidth="1.7"><circle cx="12" cy="12" r="9.2"/><circle cx="12" cy="12" r="2.4" fill="#1a1a1a" stroke="none"/><path d="M4.2 10.5c2.2.4 4.4.6 7.8.6s5.6-.2 7.8-.6M12 14.4V21"/></svg>Matic</span>
                  <span style={s(`display:flex;align-items:center;gap:6px`)}><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="#1a1a1a" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><rect x="4" y="3.5" width="8.5" height="17" rx="1.6"/><line x1="4" y1="9" x2="12.5" y2="9"/><path d="M12.5 6.6l3.8 3v8a1.9 1.9 0 0 0 3.8 0V9.6"/></svg>Bensin</span>
                  <span style={s(`display:flex;align-items:center;gap:6px`)}><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="#1a1a1a" strokeWidth="1.7"><circle cx="12" cy="8" r="3.6"/><path d="M5 20c0-3.9 3.1-6 7-6s7 2.1 7 6"/></svg>Optional</span>
                </div>
                <div className="pesan-btn" style={s(`background:#4149DC;border-radius:22px;height:44px;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:18px;color:#fff`)}>Rp. 300.000</div>
              </div>
              <div data-card style={s(`background:#fff;border-radius:16px;box-shadow:0 22px 40px rgba(20,20,60,.10);padding:26px 26px 24px;text-align:left`)}>
                <div style={s(`font-weight:800;font-size:24px;color:#141414`)}>Fronx</div>
                <div style={s(`font-size:20px;color:#141414;margin-top:-3px`)}>GX</div>
                <img src="/assets/d_alphard2.png" style={s(`width:100%;height:auto;display:block;margin:18px 0 20px`)} />
                <div style={s(`display:flex;justify-content:space-between;margin-bottom:16px;font-size:13.5px;color:#1a1a1a`)}>
                  <span style={s(`display:flex;align-items:center;gap:6px`)}><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="#1a1a1a" strokeWidth="1.7"><circle cx="12" cy="12" r="9.2"/><circle cx="12" cy="12" r="2.4" fill="#1a1a1a" stroke="none"/><path d="M4.2 10.5c2.2.4 4.4.6 7.8.6s5.6-.2 7.8-.6M12 14.4V21"/></svg>Matic</span>
                  <span style={s(`display:flex;align-items:center;gap:6px`)}><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="#1a1a1a" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><rect x="4" y="3.5" width="8.5" height="17" rx="1.6"/><line x1="4" y1="9" x2="12.5" y2="9"/><path d="M12.5 6.6l3.8 3v8a1.9 1.9 0 0 0 3.8 0V9.6"/></svg>Bensin</span>
                  <span style={s(`display:flex;align-items:center;gap:6px`)}><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="#1a1a1a" strokeWidth="1.7"><circle cx="12" cy="8" r="3.6"/><path d="M5 20c0-3.9 3.1-6 7-6s7 2.1 7 6"/></svg>Driver</span>
                </div>
                <div className="pesan-btn" style={s(`background:#4149DC;border-radius:22px;height:44px;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:18px;color:#fff`)}>Rp. 1.300.000</div>
              </div>
            </div>
          </div>
    
          
          <div style={s(`padding:96px 0 0;text-align:center`)}>
            <h2 style={s(`font-weight:800;font-size:38px;line-height:1.15;margin:0 0 14px;color:#141414`)}>Best Service and<br />Best Price</h2>
            <p style={s(`margin:0 auto 30px;font-size:13.5px;line-height:1.5;color:#3f3f3f;max-width:430px`)}>Lorem ipsum dolor sit amet consectetur. Nunc pulvinar arcu proin phasellus bibendum mauris proin nulla donec. Lorem non nunc odio lectus. Duis blandit.</p>
            <div style={s(`display:flex;align-items:center;justify-content:center;gap:20px;max-width:1240px;margin:0 auto;padding:0 100px`)}>
              <img src="/assets/d_alphard_big.png" style={s(`width:700px;height:auto;display:block`)} />
              <div style={s(`display:flex;flex-direction:column;gap:24px;text-align:left;width:470px`)}>
                <div style={s(`display:flex;gap:18px;align-items:flex-start`)}>
                  <div style={s(`flex:none;width:74px;height:74px;border-radius:16px;background:#305BA4;display:flex;align-items:center;justify-content:center`)}>
                    <svg width="38" height="38" viewBox="0 0 24 24" fill="#fff"><circle cx="12" cy="8" r="4"/><path d="M4 20c0-4.4 3.6-7.2 8-7.2s8 2.8 8 7.2z"/></svg>
                  </div>
                  <div>
                    <div style={s(`font-weight:700;font-size:19px;color:#141414`)}>Driver Professional</div>
                    <p style={s(`margin:3px 0 0;font-size:13px;line-height:1.45;color:#3f3f3f`)}>Lorem ipsum dolor sit amet consectetur. Blandit in at mattis dictum fames quis ac eget. Curabitur non eu donec sapien egestas aliquet sit turpis.</p>
                  </div>
                </div>
                <div style={s(`display:flex;gap:18px;align-items:flex-start`)}>
                  <div style={s(`flex:none;width:74px;height:74px;border-radius:16px;background:#305BA4;display:flex;align-items:center;justify-content:center`)}>
                    <svg width="38" height="38" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" fill="#fff"/><text x="12" y="17" fontSize="14" fontWeight="700" textAnchor="middle" fill="#305BA4" fontFamily="Poppins">$</text></svg>
                  </div>
                  <div>
                    <div style={s(`font-weight:700;font-size:19px;color:#141414`)}>Harga Bersaing</div>
                    <p style={s(`margin:3px 0 0;font-size:13px;line-height:1.45;color:#3f3f3f`)}>Lorem ipsum dolor sit amet consectetur. Blandit in at mattis dictum fames quis ac eget. Curabitur non eu donec sapien egestas aliquet sit turpis.</p>
                  </div>
                </div>
                <div style={s(`display:flex;gap:18px;align-items:flex-start`)}>
                  <div style={s(`flex:none;width:74px;height:74px;border-radius:16px;background:#305BA4;display:flex;align-items:center;justify-content:center`)}>
                    <svg width="38" height="38" viewBox="0 0 24 24" fill="#fff"><path d="M12 2l8 3v6c0 5-3.4 8.6-8 10-4.6-1.4-8-5-8-10V5z"/><path d="M8.4 12l2.4 2.4 4.8-4.9" stroke="#305BA4" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round"/></svg>
                  </div>
                  <div>
                    <div style={s(`font-weight:700;font-size:19px;color:#141414`)}>Unit Terjamin</div>
                    <p style={s(`margin:3px 0 0;font-size:13px;line-height:1.45;color:#3f3f3f`)}>Lorem ipsum dolor sit amet consectetur. Blandit in at mattis dictum fames quis ac eget. Curabitur non eu donec sapien egestas aliquet sit turpis.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
    
          
          <div style={s(`padding:120px 145px 0`)}>
            <h2 style={s(`font-weight:800;font-size:38px;margin:0 0 12px;color:#141414`)}>Contact Us</h2>
            <p style={s(`margin:0 0 20px;font-size:13.5px;line-height:1.5;color:#3f3f3f;max-width:460px`)}>Lorem ipsum dolor sit amet consectetur. Nunc pulvinar arcu proin phasellus bibendum mauris proin nulla donec. Lorem non nunc odio lectus. Duis blandit.</p>
            <div style={s(`display:flex;gap:16px;margin-bottom:34px`)}>
              <svg width="34" height="34" viewBox="0 0 24 24"><rect x="2" y="2" width="20" height="20" rx="6" fill="none" stroke="#111" strokeWidth="2"/><circle cx="12" cy="12" r="4.6" fill="none" stroke="#111" strokeWidth="2"/><circle cx="17.6" cy="6.5" r="1.3" fill="#111"/></svg>
              <svg width="34" height="34" viewBox="0 0 24 24"><circle cx="12" cy="12" r="11" fill="#111"/><path d="M13.1 12H15l.4-2.6h-2.3V7.7c0-.75.24-1.26 1.3-1.26h1.1V4.1C16.2 4.06 15.5 4 14.7 4c-1.9 0-3.2 1.16-3.2 3.3v1.1H9.3V12h2.2v6.4h2.6z" fill="#fff"/></svg>
              <svg width="34" height="34" viewBox="0 0 24 24"><circle cx="12" cy="12" r="11" fill="#111"/><path d="M12 5.6a6.3 6.3 0 0 0-5.4 9.6L5.7 18.4l3.4-.9A6.3 6.3 0 1 0 12 5.6z" fill="none" stroke="#fff" strokeWidth="1.2"/><path d="M9.5 8.9c-.15-.4-.3-.35-.45-.35h-.4c-.13 0-.35.05-.53.27-.18.22-.7.68-.7 1.66s.72 1.92.82 2.05c.1.13 1.4 2.24 3.48 3.05 1.72.67 2.07.53 2.44.5.37-.03 1.2-.49 1.37-.97.17-.47.17-.87.12-.96-.05-.08-.18-.13-.38-.23s-1.2-.6-1.39-.67c-.18-.07-.3-.1-.44.1s-.5.66-.62.8c-.1.12-.22.14-.42.05a5.5 5.5 0 0 1-1.63-1.01 6.1 6.1 0 0 1-1.13-1.4c-.12-.2 0-.31.09-.4.09-.09.2-.23.29-.35.1-.12.13-.2.2-.33.06-.13.03-.25-.02-.35z" fill="#fff"/></svg>
            </div>
            <div style={s(`display:flex;gap:56px;align-items:flex-start`)}>
              <div style={s(`width:460px`)}>
                <div style={s(`background:#c0d8ff;border-radius:22px;height:40px;display:flex;align-items:center;padding:0 18px;font-weight:500;font-size:13px;color:#7f89b0`)}>Jenny Wilson</div>
                <div style={s(`display:flex;gap:22px;margin-top:16px`)}>
                  <div style={s(`flex:1`)}>
                    <div style={s(`font-weight:700;font-size:13px;margin-bottom:6px`)}>Pilih Tanggal Sewa</div>
                    <div style={s(`background:#c0d8ff;border-radius:22px;height:40px;display:flex;align-items:center;padding:0 18px;font-weight:500;font-size:13px;color:#7f89b0`)}>6/10/2025</div>
                  </div>
                  <div style={s(`flex:1`)}>
                    <div style={s(`font-weight:700;font-size:13px;margin-bottom:6px`)}>Pilih Tanggal Kembali</div>
                    <div style={s(`background:#c0d8ff;border-radius:22px;height:40px;display:flex;align-items:center;padding:0 18px;font-weight:500;font-size:13px;color:#7f89b0`)}>7/10/2025</div>
                  </div>
                </div>
                <div style={s(`font-weight:700;font-size:13px;margin:16px 0 6px`)}>Pilih Tipe Mobil</div>
                <div style={s(`background:#c0d8ff;border-radius:22px;height:40px;display:flex;align-items:center;padding:0 18px;font-weight:500;font-size:13px;color:#7f89b0`)}>Toyota Innova Reborn</div>
                <div style={s(`font-weight:700;font-size:13px;margin:16px 0 6px`)}>Pilih Kebutuhan</div>
                <div style={s(`background:#c0d8ff;border-radius:22px;height:40px;display:flex;align-items:center;padding:0 18px;font-weight:500;font-size:13px;color:#7f89b0`)}>Tanpa Supir</div>
                <div className="pesan-btn" style={s(`background:#305BA4;border-radius:24px;height:48px;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:20px;color:#fff;margin-top:22px`)}>Pesan Sekarang</div>
              </div>
              <div style={s(`flex:1`)}>
                <img src="/assets/d_map.png" style={s(`width:100%;height:auto;display:block;border-radius:14px;box-shadow:0 18px 40px rgba(0,0,0,.14)`)} />
              </div>
            </div>
          </div>
    
          <div style={s(`margin-top:80px;background:#305BA4;height:52px;display:flex;align-items:center;justify-content:center;font-size:14px;color:#dbe4f4`)}>© Rent Car, All Right Reserved</div>
        </div>
      </div>
  );
}
