import { s } from './style';
import MobileFrame from './MobileFrame';
import DesktopFrame from './DesktopFrame';
import './index.css';

export default function App() {
  return (
    <div style={s('display:flex;gap:70px;padding:64px;align-items:flex-start;width:max-content')}>
      <MobileFrame />
      <DesktopFrame />
    </div>
  );
}
