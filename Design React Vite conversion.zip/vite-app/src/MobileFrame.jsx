import { s } from './style';

export default function MobileFrame() {
  return (
    <div style={s(`display:flex;flex-direction:column;align-items:flex-start`)}>
        <span className="frame-lbl">Mobile · iPhone 13 &amp; 14</span>
        <div style={s(`width:390px;background:#ffffff;border-radius:26px;box-shadow:0 24px 70px rgba(0,0,0,.18);overflow:hidden;color:#141414`)}>
    
          
          <div style={s(`position:relative;height:312px;overflow:hidden`)}>
            <div style={s(`position:absolute;top:0;right:0;width:222px;height:246px;background:radial-gradient(130% 105% at 42% 52%,#c0b8ff 0%,#948cfd 56%,#857df7 100%)`)}></div>
            <img src="/assets/m_jimny.png" alt="Suzuki Jimny" style={s(`position:absolute;top:141px;right:0;width:320px;height:auto;filter:drop-shadow(0 10px 10px rgba(0,0,0,.18))`)} />
            <div style={s(`position:absolute;top:24px;left:22px;display:flex;align-items:center;gap:7px`)}>
              <svg width="26" height="19" viewBox="0 0 44 30"><path fill="#E4002B" d="M22 1h20l-8 11H14z M2 18h20l8 11H10z"/></svg>
              <span style={s(`font-weight:800;font-size:15px;letter-spacing:.04em;color:#141a4d`)}>SUZUKI</span>
            </div>
            <div style={s(`position:absolute;top:58px;left:22px;width:262px`)}>
              <div style={s(`font-weight:800;font-size:21px;line-height:1.2;color:#141414;white-space:nowrap`)}>Suzuki Mobil Semarang</div>
              <div style={s(`font-weight:700;font-size:21px;line-height:1.2;color:#141414;margin-top:3px`)}>Mobil Nyaman, Harga<br />Aman.</div>
            </div>
          </div>
    
          
          <div style={s(`padding:6px 22px 0`)}>
            <h2 style={s(`font-weight:800;font-size:24px;margin:14px 0 18px;color:#141414`)}>How To Order</h2>
            <div style={s(`display:flex;flex-direction:column;gap:18px`)}>
              <div style={s(`display:flex;gap:16px;align-items:flex-start`)}>
                <div style={s(`flex:none;width:56px;height:56px;border-radius:15px;background:#3350c4;display:flex;align-items:center;justify-content:center`)}>
                  <svg width="30" height="30" viewBox="0 0 24 24" fill="#fff"><path d="M5 11l1.5-3.8A2.2 2.2 0 0 1 8.6 5.8h6.8a2.2 2.2 0 0 1 2.1 1.4L19 11h.4A1.6 1.6 0 0 1 21 12.6V16a1 1 0 0 1-1 1h-1v1.1a1.1 1.1 0 0 1-2.2 0V17H7.2v1.1a1.1 1.1 0 0 1-2.2 0V17H4a1 1 0 0 1-1-1v-3.4A1.6 1.6 0 0 1 4.6 11z"/><circle cx="7.6" cy="14" r="1.2" fill="#3350c4"/><circle cx="16.4" cy="14" r="1.2" fill="#3350c4"/></svg>
                </div>
                <div>
                  <div style={s(`font-weight:700;font-size:16px;color:#141414`)}>Pilih Tipe Kendaraan</div>
                  <p style={s(`margin:2px 0 0;font-size:13.5px;line-height:1.4;color:#3f3f3f`)}>Temukan berbagai pilihan mobil Suzuki yang sesuai dengan kebutuhan Anda. Mulai dari city car, MPV, SUV, hingga kendaraan niaga</p>
                </div>
              </div>
              <div style={s(`display:flex;gap:16px;align-items:flex-start`)}>
                <div style={s(`flex:none;width:56px;height:56px;border-radius:15px;background:#3350c4;display:flex;align-items:center;justify-content:center`)}>
                  <svg width="30" height="30" viewBox="0 0 24 24"><rect x="3.5" y="5" width="17" height="15" rx="2.4" fill="#fff"/><rect x="3.5" y="5" width="17" height="4.4" fill="#e7ebff"/><line x1="8" y1="3" x2="8" y2="6.5" stroke="#fff" strokeWidth="2" strokeLinecap="round"/><line x1="16" y1="3" x2="16" y2="6.5" stroke="#fff" strokeWidth="2" strokeLinecap="round"/><text x="12" y="17.5" fontSize="8.5" fontWeight="700" textAnchor="middle" fill="#3350c4" fontFamily="Poppins">19</text></svg>
                </div>
                <div>
                  <div style={s(`font-weight:700;font-size:16px;color:#141414`)}>SPK</div>
                  <p style={s(`margin:2px 0 0;font-size:13.5px;line-height:1.4;color:#3f3f3f`)}>Tim kami akan membantu Anda mulai dari pemilihan unit, pengajuan pembelian, hingga penyelesaian administrasi.</p>
                </div>
              </div>
              <div style={s(`display:flex;gap:16px;align-items:flex-start`)}>
                <div style={s(`flex:none;width:56px;height:56px;border-radius:15px;background:#3350c4;display:flex;align-items:center;justify-content:center`)}>
                  <svg width="28" height="28" viewBox="0 0 24 24" fill="#fff"><path d="M12 2C7.9 2 4.5 5.3 4.5 9.4c0 5.4 6.3 11.7 7 12.4.3.3.7.3 1 0 .7-.7 7-7 7-12.4C19.5 5.3 16.1 2 12 2z"/><circle cx="12" cy="9.4" r="2.7" fill="#3350c4"/></svg>
                </div>
                <div>
                  <div style={s(`font-weight:700;font-size:16px;color:#141414`)}>Delivery Order</div>
                  <p style={s(`margin:2px 0 0;font-size:13.5px;line-height:1.4;color:#3f3f3f`)}>Setelah seluruh proses administrasi selesai, mobil Suzuki Anda akan kami siapkan dan kirim sesuai jadwal yang telah disepakati.</p>
                </div>
              </div>
            </div>
          </div>
    
          
          <div style={s(`padding:30px 0 0`)}>
            <h2 style={s(`font-weight:800;font-size:24px;margin:0 22px 14px;color:#141414`)}>Our Unit Cars</h2>
            <div style={s(`margin:0 22px 20px;background:#c6d6fb;border-radius:26px;height:48px;display:flex;align-items:center;justify-content:space-between;padding:0 20px`)}>
              <span style={s(`font-weight:600;font-size:15px;color:#7c86a8`)}>Pilih Kendaraan</span>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#5560a8" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round"><path d="M6 9l6 6 6-6"/></svg>
            </div>
            <div className="m-carousel" style={s(`display:flex;gap:20px;overflow-x:auto;padding:6px 22px 30px`)}>
              
              <div style={s(`flex:none;width:296px;background:#fff;border-radius:20px;box-shadow:0 18px 34px rgba(20,20,60,.14);padding:22px 20px 20px`)}>
                <div style={s(`font-weight:800;font-size:22px;color:#141414`)}>XL7</div>
                <div style={s(`font-size:19px;color:#141414;margin-top:-2px`)}>Zeta</div>
                <img src="/assets/m_xl7.png" alt="XL7 Zeta" style={s(`width:100%;height:auto;display:block;margin:14px 0 18px`)} />
                <div style={s(`display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;font-size:13px;color:#1a1a1a`)}>
                  <span style={s(`display:flex;align-items:center;gap:6px`)}><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#1a1a1a" strokeWidth="1.7"><circle cx="12" cy="12" r="9.2"/><circle cx="12" cy="12" r="2.4" fill="#1a1a1a" stroke="none"/><path d="M4.2 10.5c2.2.4 4.4.6 7.8.6s5.6-.2 7.8-.6M12 14.4V21"/></svg>AT/MT</span>
                  <span style={s(`display:flex;align-items:center;gap:6px`)}><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#1a1a1a" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><rect x="4" y="3.5" width="8.5" height="17" rx="1.6"/><line x1="4" y1="9" x2="12.5" y2="9"/><path d="M12.5 6.6l3.8 3v8a1.9 1.9 0 0 0 3.8 0V9.6"/></svg>Bensin</span>
                  <span style={s(`display:flex;align-items:center;gap:6px`)}><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#1a1a1a" strokeWidth="1.6"><ellipse cx="12" cy="6.5" rx="7.5" ry="3"/><path d="M4.5 6.5v5c0 1.66 3.36 3 7.5 3s7.5-1.34 7.5-3v-5"/><path d="M4.5 11.5v5c0 1.66 3.36 3 7.5 3s7.5-1.34 7.5-3v-5"/></svg>Cash/Kredit</span>
                </div>
                <div style={s(`background:#c6d6fb;border-radius:22px;height:46px;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:19px;color:#20264a`)}>Rp. 285.000.000</div>
              </div>
              
              <div style={s(`flex:none;width:296px;background:#fff;border-radius:20px;box-shadow:0 18px 34px rgba(20,20,60,.14);padding:22px 20px 20px`)}>
                <div style={s(`font-weight:800;font-size:22px;color:#141414`)}>XL7</div>
                <div style={s(`font-size:19px;color:#141414;margin-top:-2px`)}>Beta</div>
                <img src="/assets/m_xl7.png" alt="XL7 Beta" style={s(`width:100%;height:auto;display:block;margin:14px 0 18px;filter:grayscale(.15)`)} />
                <div style={s(`display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;font-size:13px;color:#1a1a1a`)}>
                  <span style={s(`display:flex;align-items:center;gap:6px`)}><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#1a1a1a" strokeWidth="1.7"><circle cx="12" cy="12" r="9.2"/><circle cx="12" cy="12" r="2.4" fill="#1a1a1a" stroke="none"/><path d="M4.2 10.5c2.2.4 4.4.6 7.8.6s5.6-.2 7.8-.6M12 14.4V21"/></svg>AT/MT</span>
                  <span style={s(`display:flex;align-items:center;gap:6px`)}><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#1a1a1a" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><rect x="4" y="3.5" width="8.5" height="17" rx="1.6"/><line x1="4" y1="9" x2="12.5" y2="9"/><path d="M12.5 6.6l3.8 3v8a1.9 1.9 0 0 0 3.8 0V9.6"/></svg>Bensin</span>
                  <span style={s(`display:flex;align-items:center;gap:6px`)}><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#1a1a1a" strokeWidth="1.6"><ellipse cx="12" cy="6.5" rx="7.5" ry="3"/><path d="M4.5 6.5v5c0 1.66 3.36 3 7.5 3s7.5-1.34 7.5-3v-5"/><path d="M4.5 11.5v5c0 1.66 3.36 3 7.5 3s7.5-1.34 7.5-3v-5"/></svg>Cash/Kredit</span>
                </div>
                <div style={s(`background:#c6d6fb;border-radius:22px;height:46px;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:19px;color:#20264a`)}>Rp. 265.000.000</div>
              </div>
            </div>
          </div>
    
          
          <div style={s(`padding:6px 22px 0`)}>
            <h2 style={s(`font-weight:800;font-size:24px;margin:0;color:#141414`)}>Best Service and Best Price</h2>
            <p style={s(`margin:6px 0 6px;font-size:14px;color:#3f3f3f`)}>Dapatkan Mobil Suzuki Impian Anda Sekarang!"</p>
            <img src="/assets/m_fronx.png" alt="Suzuki Fronx" style={s(`width:100%;height:auto;display:block;margin:8px 0 22px`)} />
          </div>
    
          
          <div style={s(`padding:0 22px 0`)}>
            <div style={s(`display:flex;flex-direction:column;gap:20px`)}>
              <div style={s(`display:flex;gap:16px;align-items:flex-start`)}>
                <div style={s(`flex:none;width:56px;height:56px;border-radius:15px;background:#4149DC;display:flex;align-items:center;justify-content:center`)}>
                  <svg width="30" height="30" viewBox="0 0 24 24" fill="#fff"><circle cx="12" cy="8" r="4"/><path d="M4 20c0-4.4 3.6-7.2 8-7.2s8 2.8 8 7.2z"/></svg>
                </div>
                <div>
                  <div style={s(`font-weight:700;font-size:17px;color:#141414`)}>Pelayanan Terbaik</div>
                  <p style={s(`margin:2px 0 0;font-size:13.5px;line-height:1.4;color:#3f3f3f`)}>Kami berkomitmen memberikan pelayanan yang profesional, ramah, dan responsif.</p>
                </div>
              </div>
              <div style={s(`display:flex;gap:16px;align-items:flex-start`)}>
                <div style={s(`flex:none;width:56px;height:56px;border-radius:15px;background:#4149DC;display:flex;align-items:center;justify-content:center`)}>
                  <svg width="30" height="30" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" fill="#fff"/><text x="12" y="17" fontSize="14" fontWeight="700" textAnchor="middle" fill="#4149DC" fontFamily="Poppins">$</text></svg>
                </div>
                <div>
                  <div style={s(`font-weight:700;font-size:17px;color:#141414`)}>Harga Bersaing</div>
                  <p style={s(`margin:2px 0 0;font-size:13.5px;line-height:1.4;color:#3f3f3f`)}>Kami membantu Anda mendapatkan mobil Suzuki dengan nilai terbaik sesuai kebutuhan dan anggaran.</p>
                </div>
              </div>
              <div style={s(`display:flex;gap:16px;align-items:flex-start`)}>
                <div style={s(`flex:none;width:56px;height:56px;border-radius:15px;background:#4149DC;display:flex;align-items:center;justify-content:center`)}>
                  <svg width="30" height="30" viewBox="0 0 24 24" fill="#fff"><path d="M12 2l8 3v6c0 5-3.4 8.6-8 10-4.6-1.4-8-5-8-10V5z"/><path d="M8.4 12l2.4 2.4 4.8-4.9" stroke="#4149DC" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round"/></svg>
                </div>
                <div>
                  <div style={s(`font-weight:700;font-size:17px;color:#141414`)}>Unit Terjamin</div>
                  <p style={s(`margin:2px 0 0;font-size:13.5px;line-height:1.4;color:#3f3f3f`)}>Kami memastikan Anda mendapatkan mobil yang aman, nyaman, dan sesuai dengan standar kualitas Suzuki.</p>
                </div>
              </div>
            </div>
          </div>
    
          
          <div style={s(`padding:34px 22px 0`)}>
            <h2 style={s(`font-weight:800;font-size:24px;margin:0 0 -6px;color:#141414;position:relative;z-index:2`)}>Contact Us</h2>
            <div style={s(`display:flex;gap:16px;align-items:flex-start`)}>
              <div style={s(`flex:none;width:120px`)}>
                <img src="/assets/m_person.png" alt="Sales" style={s(`width:118px;height:auto;display:block`)} />
              </div>
              <div style={s(`flex:1;padding-top:2px`)}>
                <p style={s(`margin:0 0 16px;font-size:13.5px;line-height:1.45;color:#141414`)}>Butuh informasi lebih lanjut mengenai promo, harga, atau pembelian mobil Suzuki? Hubungi kami sekarang.</p>
                <div style={s(`display:flex;flex-direction:column;gap:14px`)}>
                  <div style={s(`display:flex;align-items:center;gap:12px`)}>
                    <svg width="34" height="34" viewBox="0 0 24 24"><circle cx="12" cy="12" r="11" fill="#111"/><path d="M12 5.6a6.3 6.3 0 0 0-5.4 9.6L5.7 18.4l3.4-.9A6.3 6.3 0 1 0 12 5.6z" fill="none" stroke="#fff" strokeWidth="1.2"/><path d="M9.5 8.9c-.15-.4-.3-.35-.45-.35h-.4c-.13 0-.35.05-.53.27-.18.22-.7.68-.7 1.66s.72 1.92.82 2.05c.1.13 1.4 2.24 3.48 3.05 1.72.67 2.07.53 2.44.5.37-.03 1.2-.49 1.37-.97.17-.47.17-.87.12-.96-.05-.08-.18-.13-.38-.23s-1.2-.6-1.39-.67c-.18-.07-.3-.1-.44.1s-.5.66-.62.8c-.1.12-.22.14-.42.05a5.5 5.5 0 0 1-1.63-1.01 6.1 6.1 0 0 1-1.13-1.4c-.12-.2 0-.31.09-.4.09-.09.2-.23.29-.35.1-.12.13-.2.2-.33.06-.13.03-.25-.02-.35z" fill="#fff"/></svg>
                    <span style={s(`font-weight:700;font-size:15px;color:#141414`)}>0821-330-7751 (MAX)</span>
                  </div>
                  <div style={s(`display:flex;align-items:center;gap:12px`)}>
                    <svg width="34" height="34" viewBox="0 0 24 24"><circle cx="12" cy="12" r="11" fill="#111"/><path d="M13.1 12H15l.4-2.6h-2.3V7.7c0-.75.24-1.26 1.3-1.26h1.1V4.1C16.2 4.06 15.5 4 14.7 4c-1.9 0-3.2 1.16-3.2 3.3v1.1H9.3V12h2.2v6.4h2.6z" fill="#fff"/></svg>
                    <span style={s(`font-weight:700;font-size:15px;color:#141414`)}>Max Suzuki SIT BSB</span>
                  </div>
                  <div style={s(`display:flex;align-items:center;gap:12px`)}>
                    <svg width="34" height="34" viewBox="0 0 24 24"><circle cx="12" cy="12" r="11" fill="#111"/><rect x="6.7" y="6.7" width="10.6" height="10.6" rx="3.4" fill="none" stroke="#fff" strokeWidth="1.5"/><circle cx="12" cy="12" r="2.8" fill="none" stroke="#fff" strokeWidth="1.5"/><circle cx="15.5" cy="8.5" r="0.9" fill="#fff"/></svg>
                    <span style={s(`font-weight:700;font-size:15px;color:#141414`)}>@maxsuzukimobil_sit</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
    
          
          <div style={s(`padding:26px 22px 4px`)}>
            <div style={s(`font-weight:700;font-size:15px;margin:0 0 7px;color:#141414`)}>Nama Penyewa</div>
            <div style={s(`background:#c6d6fb;border-radius:26px;height:48px;display:flex;align-items:center;padding:0 22px;font-weight:600;font-size:15px;color:#7c86a8;margin-bottom:16px`)}>Jenny Wilson</div>
            <div style={s(`font-weight:700;font-size:15px;margin:0 0 7px;color:#141414`)}>Pilih Tipe Mobil</div>
            <div style={s(`background:#c6d6fb;border-radius:26px;height:48px;display:flex;align-items:center;padding:0 22px;font-weight:600;font-size:15px;color:#7c86a8;margin-bottom:16px`)}>Fronx SGX</div>
            <div style={s(`font-weight:700;font-size:15px;margin:0 0 7px;color:#141414`)}>Pilih Transmisi</div>
            <div style={s(`background:#c6d6fb;border-radius:26px;height:48px;display:flex;align-items:center;padding:0 22px;font-weight:600;font-size:15px;color:#7c86a8;margin-bottom:16px`)}>AT/MT</div>
            <div style={s(`font-weight:700;font-size:15px;margin:0 0 7px;color:#141414`)}>Pilih Pembayaran</div>
            <div style={s(`background:#c6d6fb;border-radius:26px;height:48px;display:flex;align-items:center;padding:0 22px;font-weight:600;font-size:15px;color:#7c86a8;margin-bottom:22px`)}>Cash/Kredit</div>
            <div className="pesan-btn" style={s(`background:#4149DC;border-radius:30px;height:58px;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:22px;color:#fff`)}>Pesan Sekarang</div>
          </div>
    
          <div style={s(`margin-top:30px;background:#4149DC;height:44px;display:flex;align-items:center;justify-content:center;font-size:12.5px;color:#c9cffa`)}>© Suzuki Mobil Semarang, All Right Reserved</div>
        </div>
      </div>
  );
}
