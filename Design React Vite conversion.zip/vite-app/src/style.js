// Parse a CSS declaration string into a React style object.
export const s = (str) =>
  Object.fromEntries(
    str
      .split(';')
      .filter(Boolean)
      .map((decl) => {
        const i = decl.indexOf(':');
        const key = decl.slice(0, i).trim().replace(/-([a-z])/g, (_, c) => c.toUpperCase());
        return [key, decl.slice(i + 1).trim()];
      })
  );
