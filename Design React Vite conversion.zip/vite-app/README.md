# Suzuki Mobil Semarang & Rent Car — Landing (React + Vite)

Pixel recreation of the provided Figma designs (mobile "Suzuki Mobil Semarang" + desktop "Rent Car"), converted to a React + Vite project.

## Run

```bash
npm install
npm run dev
```

Then open the printed local URL. Build for production with `npm run build`.

## Structure

- `src/MobileFrame.jsx` — the mobile (iPhone) design
- `src/DesktopFrame.jsx` — the desktop (1440) design
- `src/App.jsx` — renders both frames side by side (the showcase canvas)
- `src/style.js` — `s()` helper that turns a CSS string into a React style object
- `src/index.css` — font import, resets, button hover states
- `public/assets/` — car / person / map photos cropped from the source designs

Icons are inline SVG. Colors, spacing, and typography (Poppins) match the source.
